﻿using System;
using System.Data;
using System.Globalization;
using System.Security.Authentication;

class Program
{
    static void Main(string[] args)
    {
        string menu = "";
        while (!menu.Equals("D"))
        {
            Console.Clear();
            Console.WriteLine("Laboratorio 8 - Ana Sofía Asturias To - 1078123\n");
            Console.WriteLine("Ingrese una letra para ejecutar el menú\n");

            Console.WriteLine("A. Sumatoria.");
            Console.WriteLine("B. Mostra tablas de multiplicar.");
            Console.WriteLine("C. Número Perfecto.");
            Console.WriteLine("D. Salir del programa.\n");
            
            string op = (Console.ReadLine());

            switch (op)
            {
                case "A" or "a":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Ana Sofía Asturias To - 1078123\n");
                    Console.WriteLine("Sumatoria\n");
                    int inicio = 0;
                    int sum = 0;
                    Console.Write("Ingrese un número: ");
                    int n = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("\n");
                    do
                    {
                        inicio++;
                        Console.WriteLine(inicio);
                        sum = sum + inicio;
                    } while (inicio < n);
                    
                    Console.WriteLine("\nLa suma de los números es: " + sum);

                    Console.ReadKey();
                    break;

                case "B" or "b":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Ana Sofía Asturias To - 1078123\n");
                    Console.WriteLine("Tablas de multiplicar\n");

                    Console.Write("Ingrese un número: ");
                    int x = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("\n");

                    int multi;

                    for (int i = 1; i <= 10; i++)
                    {
                        multi = x * i;
                        Console.WriteLine(x + " * " + i + " = " + multi);
                    }
                    
                    Console.ReadKey();
                    break;

                case "C" or "c":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Ana Sofía Asturias To - 1078123\n");
                    Console.WriteLine("Número perfecto\n");

                    int p = 0;
                    int s = 0;
                    Console.Write("Ingrese un número entero: ");

                    bool a = int.TryParse(Console.ReadLine(), out p);

                    if (a == true)
                    {
                        if (p > 0)
                        {
                            for (int y = 1; y < p; y++)
                            {
                                if (p % y == 0)
                                {
                                    s = s + y;
                                }
                            }
                            if (s == p)
                            {
                                Console.WriteLine("\nEs un número perfecto.\n");
                            }
                            else
                            {
                                Console.WriteLine("\nNo es un número perfecto.\n");
                            }
                        }
                        else
                        {
                            Console.WriteLine("\nNo es un número mayor a 0.\n");
                        }
                    }
                    else
                    {
                        Console.WriteLine("\nNo es un número.\n");
                    }

                    Console.ReadKey();
                    break;

                case "D" or "d":
                    Console.Clear();
                    Console.WriteLine("Laboratorio 8 - Ana Sofía Asturias To - 1078123\n");
                    menu = "D";
                    Console.WriteLine("Adiós :)");
                    Console.ReadKey();
                    break;

                default:
                    Console.WriteLine("Letra invalda.");
                    break;

            }

        }
    }
}