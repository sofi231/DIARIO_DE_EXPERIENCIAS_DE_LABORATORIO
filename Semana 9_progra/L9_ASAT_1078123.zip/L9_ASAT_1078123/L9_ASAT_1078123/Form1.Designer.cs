﻿namespace L9_ASAT_1078123
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            TabPage tabPage1;
            txtCambio = new TextBox();
            txtMarca = new TextBox();
            txtPrecio = new TextBox();
            txtModelo = new TextBox();
            lblCambio = new Label();
            lblMarca = new Label();
            lblPrecio = new Label();
            lblModelo = new Label();
            btnGuardar = new Button();
            lblTitulo = new Label();
            tabControl1 = new TabControl();
            tabPage2 = new TabPage();
            button1 = new Button();
            txtDatosAutomovil = new TextBox();
            txtDescuento = new TextBox();
            lblDescuento = new Label();
            btnAplicar = new Button();
            btnLimpiar = new Button();
            btnSalir = new Button();
            tabPage1 = new TabPage();
            tabPage1.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(txtCambio);
            tabPage1.Controls.Add(txtMarca);
            tabPage1.Controls.Add(txtPrecio);
            tabPage1.Controls.Add(txtModelo);
            tabPage1.Controls.Add(lblCambio);
            tabPage1.Controls.Add(lblMarca);
            tabPage1.Controls.Add(lblPrecio);
            tabPage1.Controls.Add(lblModelo);
            tabPage1.Controls.Add(btnGuardar);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(445, 369);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Ingreso de Datos";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtCambio
            // 
            txtCambio.Location = new Point(243, 177);
            txtCambio.Name = "txtCambio";
            txtCambio.Size = new Size(125, 27);
            txtCambio.TabIndex = 8;
            txtCambio.Text = "7,50";
            txtCambio.TextChanged += txtCambio_TextChanged;
            // 
            // txtMarca
            // 
            txtMarca.Location = new Point(243, 144);
            txtMarca.Name = "txtMarca";
            txtMarca.Size = new Size(125, 27);
            txtMarca.TabIndex = 7;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(243, 114);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(125, 27);
            txtPrecio.TabIndex = 6;
            // 
            // txtModelo
            // 
            txtModelo.Location = new Point(243, 84);
            txtModelo.Name = "txtModelo";
            txtModelo.Size = new Size(125, 27);
            txtModelo.TabIndex = 5;
            txtModelo.TextChanged += txtModelo_TextChanged;
            // 
            // lblCambio
            // 
            lblCambio.AutoSize = true;
            lblCambio.Location = new Point(78, 180);
            lblCambio.Name = "lblCambio";
            lblCambio.Size = new Size(119, 20);
            lblCambio.TabIndex = 4;
            lblCambio.Text = "Tipo de Cambio:";
            // 
            // lblMarca
            // 
            lblMarca.AutoSize = true;
            lblMarca.Location = new Point(78, 147);
            lblMarca.Name = "lblMarca";
            lblMarca.Size = new Size(53, 20);
            lblMarca.TabIndex = 3;
            lblMarca.Text = "Marca:";
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Location = new Point(78, 114);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(53, 20);
            lblPrecio.TabIndex = 2;
            lblPrecio.Text = "Precio:";
            // 
            // lblModelo
            // 
            lblModelo.AutoSize = true;
            lblModelo.Location = new Point(78, 84);
            lblModelo.Name = "lblModelo";
            lblModelo.Size = new Size(64, 20);
            lblModelo.TabIndex = 1;
            lblModelo.Text = "Modelo:";
            // 
            // btnGuardar
            // 
            btnGuardar.Location = new Point(153, 263);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new Size(129, 57);
            btnGuardar.TabIndex = 0;
            btnGuardar.Text = "Guardar Disponibilidad";
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.Font = new Font("Tempus Sans ITC", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblTitulo.Location = new Point(185, 25);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(426, 39);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = "LABORATORIO CON CLASES";
            lblTitulo.Click += label1_Click;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(176, 101);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(453, 402);
            tabControl1.TabIndex = 1;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(button1);
            tabPage2.Controls.Add(txtDatosAutomovil);
            tabPage2.Controls.Add(txtDescuento);
            tabPage2.Controls.Add(lblDescuento);
            tabPage2.Controls.Add(btnAplicar);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(445, 369);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Datos Automóvil";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Tempus Sans ITC", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.Navy;
            button1.Location = new Point(114, 280);
            button1.Name = "button1";
            button1.Size = new Size(210, 50);
            button1.TabIndex = 4;
            button1.Text = "Cambiar Disponibilidad";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtDatosAutomovil
            // 
            txtDatosAutomovil.Location = new Point(104, 94);
            txtDatosAutomovil.Multiline = true;
            txtDatosAutomovil.Name = "txtDatosAutomovil";
            txtDatosAutomovil.ScrollBars = ScrollBars.Vertical;
            txtDatosAutomovil.Size = new Size(235, 168);
            txtDatosAutomovil.TabIndex = 3;
            // 
            // txtDescuento
            // 
            txtDescuento.Location = new Point(25, 45);
            txtDescuento.Name = "txtDescuento";
            txtDescuento.Size = new Size(125, 27);
            txtDescuento.TabIndex = 2;
            // 
            // lblDescuento
            // 
            lblDescuento.AutoSize = true;
            lblDescuento.Location = new Point(25, 22);
            lblDescuento.Name = "lblDescuento";
            lblDescuento.Size = new Size(79, 20);
            lblDescuento.TabIndex = 1;
            lblDescuento.Text = "Descuento";
            // 
            // btnAplicar
            // 
            btnAplicar.Location = new Point(303, 24);
            btnAplicar.Name = "btnAplicar";
            btnAplicar.Size = new Size(94, 29);
            btnAplicar.TabIndex = 0;
            btnAplicar.Text = "Aplicar";
            btnAplicar.UseVisualStyleBackColor = true;
            btnAplicar.Click += btnAplicar_Click;
            // 
            // btnLimpiar
            // 
            btnLimpiar.Location = new Point(635, 375);
            btnLimpiar.Name = "btnLimpiar";
            btnLimpiar.Size = new Size(94, 29);
            btnLimpiar.TabIndex = 2;
            btnLimpiar.Text = "Limpiar";
            btnLimpiar.UseVisualStyleBackColor = true;
            btnLimpiar.Click += btnLimpiar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Location = new Point(635, 421);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new Size(94, 29);
            btnSalir.TabIndex = 3;
            btnSalir.Text = "Salir";
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 542);
            Controls.Add(btnSalir);
            Controls.Add(btnLimpiar);
            Controls.Add(tabControl1);
            Controls.Add(lblTitulo);
            Name = "Form1";
            Text = "s";
            Load += Form1_Load;
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitulo;
        private TabControl tabControl1;
        private TextBox txtCambio;
        private TextBox txtMarca;
        private TextBox txtPrecio;
        private TextBox txtModelo;
        private Label lblCambio;
        private Label lblMarca;
        private Label lblPrecio;
        private Label lblModelo;
        private Button btnGuardar;
        private TabPage tabPage2;
        private Button button1;
        private TextBox txtDatosAutomovil;
        private TextBox txtDescuento;
        private Label lblDescuento;
        private Button btnAplicar;
        private Button btnLimpiar;
        private Button btnSalir;
    }
}