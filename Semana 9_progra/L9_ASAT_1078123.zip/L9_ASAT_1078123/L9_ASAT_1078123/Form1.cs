namespace L9_ASAT_1078123
{
    public partial class Form1 : Form
    {
        public Form1()
        { //inicializar el form
            InitializeComponent();
        }

        //crear la instancia de la clase
        Automovil myAutomovil = new Automovil();

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            //obtener lo que est� en la caja de texto y se guarda en la clase
            myAutomovil.DefinirPrecio(Convert.ToDouble(txtPrecio.Text));
            myAutomovil.DefinirModelo(Convert.ToInt32(txtModelo.Text));
            myAutomovil.DefinirMarca(txtMarca.Text);
            myAutomovil.DefinirCambioDolar(Convert.ToDouble(txtCambio.Text));

            MessageBox.Show("Los Datos se guardaron exitosamente");

            txtDatosAutomovil.Text = myAutomovil.MostrarInformacion();
        }

        private void txtModelo_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAplicar_Click(object sender, EventArgs e)
        {
            myAutomovil.AplicarDescuento(Convert.ToDouble(txtDescuento.Text));
            txtDatosAutomovil.Text = myAutomovil.MostrarInformacion();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            myAutomovil.CambiarDisponibilidad(true);
            txtDatosAutomovil.Text = myAutomovil.MostrarInformacion();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtDatosAutomovil.Clear();
            txtDescuento.Clear();
            txtCambio.Clear();
            txtMarca.Clear();
            txtModelo.Clear();
            txtPrecio.Clear();

        }

        private void txtCambio_TextChanged(object sender, EventArgs e)
        {

        }
        ///////


    }

}
