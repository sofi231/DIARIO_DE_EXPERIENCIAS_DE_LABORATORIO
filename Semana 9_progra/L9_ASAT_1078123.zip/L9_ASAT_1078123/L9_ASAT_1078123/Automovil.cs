﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L9_ASAT_1078123
{
    public class Automovil
    {
        //declarar atributos privados de nuestra clase automovil para que sean utilizadas solo por esta
        private int modelo;
        private double precio, tipoCambioDolar, descuentoAplicado;
        private string marca;
        private bool disponible;

        //métodos get y set quen nos permiten enviar y recibir variables get: recibir datos, set: enviar datos

        public int Modelo { get { return modelo; } }
        public double Precio { get { return precio; } }
        public double TipoCambioDolar { get { return tipoCambioDolar; } }
        public double DescuentoAplicado { get { return descuentoAplicado; } }
        public string Marca { get { return marca; } }

        public Automovil()
        {
            modelo = 2019;
            precio = 10000.00;
            marca = string.Empty;
            disponible = false;
            tipoCambioDolar = 7.50;
            descuentoAplicado = 0;
        }

        public void DefinirModelo(int unModelo)
        {
            modelo = unModelo;
        }

        public void DefinirPrecio(double unPrecio)
        {
            precio = unPrecio;
        }

        public void DefinirMarca(string unaMarca)
        {
            marca = unaMarca;
        }

        public void DefinirCambioDolar(double unTipoCambio)
        {
            tipoCambioDolar = unTipoCambio;
        }

        public void CambiarDisponibilidad(bool Disponible)
        {
            disponible = Disponible;
            if (disponible)
            {
                disponible = true;
            }
            else
            {
                disponible = false;
            }
        }

        public string MostrarDisponibilidad()
        {
            if (disponible == true)
            {
                return "Disponible";
            }
            else
            {
                return "No se encuentra disponible actualmente";
            }
        }

        public double Conversion()
        {
            return precio / TipoCambioDolar;
        }
        public string MostrarInformacion()
        {
            return $"Marca: {marca}. \r\nModelo: {modelo}. \r\nPrecio de venta: {precio}. \r\nPrecio en dolares: ${Conversion()}. \r\n{MostrarDisponibilidad()}.";
        }

        public void AplicarDescuento(double miDescuento)
        {
            descuentoAplicado = miDescuento;
            double nuevoPrecio = precio - DescuentoAplicado;
            DefinirPrecio(nuevoPrecio);
            Conversion();
        }
    }
}
