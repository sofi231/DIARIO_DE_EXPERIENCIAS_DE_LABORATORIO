﻿using System;

class Program
{

    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 2");

        int dia;

        Console.WriteLine("Ingrese el día");
        bool canConvert = int.TryParse(Console.ReadLine(), out dia);
        
        if (canConvert == true)
        {
            switch (dia)
            {
                case 1:Console.WriteLine("DÍA: Lunes");
                    break;
                case 2:Console.WriteLine("DÍA: Martes");
                    break;
                case 3:Console.WriteLine("DÍA: Miércoles");
                    break;
                case 4:Console.WriteLine("DÍA: Jueves");
                    break;
                case 5:Console.WriteLine("DÍA: Viernes");
                    break;
                case 6:Console.WriteLine("DÍA: Sábado");
                    break;
                case 7:Console.WriteLine("DÍA: Domingo");
                    break;
                default: Console.WriteLine("ERROR: El número a ingresar debe estar contenido ente 1 y 7 ");
                    break;
            }
        }
        else
        {
            Console.WriteLine("ERROR: El número a ingresar debe estar contenido ente 1 y 7");
        }
    }
}