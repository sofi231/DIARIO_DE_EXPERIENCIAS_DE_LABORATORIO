﻿using System;

class Program
{

    static void Main(string[] args)
    {

        Console.WriteLine("Ejercicio 1");

        int n1;
          
        Console.WriteLine("Ingrese un número entero");
        bool canConvert = int.TryParse(Console.ReadLine(), out n1);

        if (canConvert == true)
        {
            if (n1 > 0)
            {
                Console.WriteLine("RESULTADO: Entero positivo");
            }
            else if (n1 < 0)
            {

                Console.WriteLine("RESULTADO: Entero negativo");
            }
            else if (n1 == 0)
            {

                Console.WriteLine("RESULTADO: Igual a 0");
            }

        }else{
            Console.WriteLine("ERROR");
        }

    }


}
