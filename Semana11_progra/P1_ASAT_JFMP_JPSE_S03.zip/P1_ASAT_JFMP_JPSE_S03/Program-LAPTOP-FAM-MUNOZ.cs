﻿using System;

class Program
{
    static void Main()
    {
        string menu = "";

        while (!menu.Equals("3"))
        {
            Console.Clear();
            Console.WriteLine("---------------------------------------");
            Console.WriteLine("            TIENDAS MAS              ");
            Console.WriteLine("Sucursal: Universidad Rafael Landívar");
            Console.WriteLine("---------------------------------------\n");

            Console.WriteLine("Porfavor ingrese una opción:    "); Console.WriteLine("");
            Console.WriteLine("1. FACTURACIÓN.");
            Console.WriteLine("2. REPORTES DE FACTURACIÓN.");
            Console.WriteLine("3. SALIR DEL PROGRAMA."); Console.WriteLine("");
            Console.Write("-> ");

            char final = 's', metodopago = 's';
            double c1 = 0, c2 = 0, c3 = 0, c4 = 0, c5 = 0, suma = 0, puntos = 0;
            int cont1 = 0, cont2 = 0, cont3 = 0, cont4 = 0, cont5 = 0, nit = 0;
            string nombre;
            string correo;

            string opcion = (Console.ReadLine());

            switch (opcion)
            {
                case "1":
                    Console.Clear();
                    Console.WriteLine("---------------------------------------");
                    Console.WriteLine("            TIENDAS MAS              ");
                    Console.WriteLine("Sucursal: Universidad Rafael Landívar");
                    Console.WriteLine("---------------------------------------\n");

                    try
                    {
                        Console.Write("Ingrese el nombre para su factura: ");
                        nombre = Console.ReadLine();
                        Console.WriteLine("");
                        Console.Write("Ingrese su número de NIT: ");
                        nit = Convert.ToInt32(Console.ReadLine());
                        Console.WriteLine("");
                        Console.Write("Ingrese su correo electrónico: ");
                        correo = Console.ReadLine();
                        Console.WriteLine("");

                        Console.Clear();

                        Console.WriteLine("---------------------------------------");
                        Console.WriteLine("            TIENDAS MAS              ");
                        Console.WriteLine("Sucursal: Universidad Rafael Landívar");
                        Console.WriteLine("---------------------------------------\n");

                        Console.WriteLine("|--------|---------------------|--------|");
                        Console.WriteLine("| Código |       Producto      | Precio |");
                        Console.WriteLine("|--------|---------------------|--------|");
                        Console.WriteLine("| 001    | Libra de Azúcar     | Q10.80 |");
                        Console.WriteLine("| 002    | Libra de Arroz      | Q3.80  |");
                        Console.WriteLine("| 003    | Galleta GAMA        | Q1.10  |");
                        Console.WriteLine("| 004    | Coca Cola           | Q17.00 |");
                        Console.WriteLine("| 005    | Libra de Café       | Q50.00 |");
                        Console.WriteLine("|--------|---------------------|--------|");

                        while (final == 's')
                        {
                            Console.WriteLine("");
                            Console.Write("Ingrese el código del producto según indica la tabla: ");
                            string codigo = (Console.ReadLine());

                            switch (codigo)
                            {
                                case "001":

                                    Console.Write("Ingrese la cantidad que desea: ");
                                    int cant1 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    double multi001 = 10.80 * cant1;
                                    multi001 = Math.Round(multi001, 2);
                                    Console.WriteLine("El monto a pagar por esta cantidad es: Q" + multi001);
                                    c1 = multi001;
                                    cont1 = cont1 + cant1;

                                    break;

                                case "002":

                                    Console.Write("Ingrese la cantidad que desea: ");
                                    int cant2 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    double multi002 = 3.80 * cant2;
                                    multi002 = Math.Round(multi002, 2);
                                    Console.WriteLine("El monto a pagar por esta cantidad es: Q" + multi002);
                                    c2 = multi002;
                                    cont2 = cont2 + cant2;

                                    break;

                                case "003":

                                    Console.Write("Ingrese la cantidad que desea: ");
                                    int cant3 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    double multi003 = 1.10 * cant3;
                                    multi003 = Math.Round(multi003, 2);
                                    Console.WriteLine("El monto a pagar por esta cantidad es: Q" + multi003);
                                    c3 = multi003;
                                    cont3 = cont3 + cant3;

                                    break;

                                case "004":

                                    Console.Write("Ingrese la cantidad que desea: ");
                                    int cant4 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    double multi004 = 17 * cant4;
                                    multi004 = Math.Round(multi004, 2);
                                    Console.WriteLine("El monto a pagar por esta cantidad es: Q" + multi004);
                                    c4 = multi004;
                                    cont4 = cont4 + cant4;

                                    break;

                                case "005":

                                    Console.Write("Ingrese la cantidad que desea: ");
                                    int cant5 = Convert.ToInt32(Console.ReadLine());
                                    Console.WriteLine("");

                                    double multi005 = 50 * cant5;
                                    multi005 = Math.Round(multi005, 2);
                                    Console.WriteLine("El monto a pagar por esta cantidad es: Q" + multi005);
                                    c5 = multi005;
                                    cont5 = cont5 + cant5;

                                    break;

                                default:

                                    Console.WriteLine("Ingresa una opción valida.");

                                    break;
                            }

                            Console.WriteLine("");
                            Console.Write("Desea seguir ingresando productos? s = si, n = no: ");
                            final = Convert.ToChar(Console.ReadLine());

                        }
                        Console.Write("\nDesea pagar con tarjeta de credito/debito? s = si, n = no: ");
                        metodopago = Convert.ToChar(Console.ReadLine());

                        // FACTURA START
                        DateTime fecha = DateTime.Now;
                        Random r = new Random();
                        suma = c1 + c2+ c3 + c4 + c5;

                        Console.Clear();
                        Console.WriteLine("---------------------------------------");
                        Console.WriteLine("            TIENDAS MAS              ");
                        Console.WriteLine("Sucursal: Universidad Rafael Landívar");
                        Console.WriteLine("          NIT: 2394965-6              ");
                        Console.WriteLine("---------------------------------------");

                        Console.WriteLine("Fecha y Hora: " + fecha);
                        Console.WriteLine("No. " + r.Next(10000, 19999));
                        Console.WriteLine("Cliente: "+ nombre);
                        Console.WriteLine("NIT: " + nit);
                        Console.WriteLine("---------------------------------------");
                        Console.WriteLine("PRODUCTOS COMPRADOS: ");
                        if (c1 > 0)
                        {
                            Console.WriteLine("Libra de Azúcar - " + cont1 + " - Q10.80 c/u - Total: Q" + c1);
                        }
                        if (c2 > 0)
                        {
                            Console.WriteLine("Libra de Arroz - " + cont2 + " - Q3.80 c/u - Total: Q" + c2);
                        }
                        if (c3 > 0)
                        {
                            Console.WriteLine("Galletas GAMMA - " + cont3 + " - Q1.10 c/u - Total: Q" + c3);
                        }
                        if (c4 > 0)
                        {
                            Console.WriteLine("Coca Cola - " + cont4 + " - Q17.00 c/u - Total: Q" + c4);
                        }
                        if (c5 > 0)
                        {
                            Console.WriteLine("Libra de Café - " + cont5 + " - Q50.00 c/u - Total: Q" + c5);
                        }
                        Console.WriteLine("---------------------------------------");
                        Console.WriteLine("TOTAL FACTURA A PAGAR = " + suma);
                        Console.WriteLine("---------------------------------------");
                        //FACTURA END

                        //PUNTOS START
                        while(metodopago == 's')
                        {
                            if (suma <= 50)
                            {
                                puntos = suma / 10;
                            }
                            else if (suma > 50 && suma <= 100)
                            {
                                puntos = (suma / 10 ) * 2;
                            }
                            else if (suma > 100)
                            {
                                puntos = (suma / 10) * 3;
                            }
                            metodopago = 'n';
                        }
                        Console.WriteLine(puntos);
                        //PUNTOS END
                    }
                    catch
                    {
                        Console.WriteLine("\nIngrese una opción valida.");
                    }

                    Console.ReadKey();
                    break;

                case "2":
                    Console.Clear();
                    Console.WriteLine("---------------------------------------");
                    Console.WriteLine("            TIENDAS MAS              ");
                    Console.WriteLine("Sucursal: Universidad Rafael Landívar");
                    Console.WriteLine("---------------------------------------\n");

                    try
                    {
                        string menu2 = "";

                        while (!menu2.Equals("3"))
                        {
                            Console.Clear();
                            Console.WriteLine("---------------------------------------");
                            Console.WriteLine("            TIENDAS MAS              ");
                            Console.WriteLine("Sucursal: Universidad Rafael Landívar");
                            Console.WriteLine("---------------------------------------\n");

                            Console.WriteLine("Porfavor ingrese una opción:    "); Console.WriteLine("");
                            Console.WriteLine("1. TOTAL DE FACTURAS REALIZADAS.");
                            Console.WriteLine("2. TOTAL DE PRODUCTOS VENDIDOS.");
                            Console.WriteLine("3. TOTAL DE PUNTOS GENERADOS."); Console.WriteLine("");
                            Console.Write("-> ");

                            string reporte = (Console.ReadLine());

                            switch (reporte)
                            {
                                case "1":



                                    break;

                                case "2":



                                    break;

                                case "3":



                                    break;

                                default:



                                    break;
                            }
                        }

                       
                    }
                    catch
                    {
                        Console.WriteLine("Ingrese una opción valida.");
                    }

                    Console.ReadKey();
                    break;

                case "3":
                    Console.Clear();
                    Console.WriteLine("---------------------------------------");
                    Console.WriteLine("            TIENDAS MAS              ");
                    Console.WriteLine("Sucursal: Universidad Rafael Landívar");
                    Console.WriteLine("---------------------------------------\n");

                    Console.WriteLine("");
                    menu = "3";
                    Console.WriteLine("Saliendo del programa...");
                    Console.WriteLine("");

                    Console.ReadKey();
                    break;

                default:

                    Console.WriteLine("Ingresa una opción valida.");

                    Console.ReadKey();
                    break;
            }
        }
    }
}
