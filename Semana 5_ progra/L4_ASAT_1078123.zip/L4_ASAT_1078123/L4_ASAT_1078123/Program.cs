﻿using System;

class Program
{
    static void Main(string[] args)
    {
        //asignar variables
        double n1;
        double n2;
        double suma;
        double mul;
        double d;
        double res;
        double div;
        double mod;

        Console.WriteLine("Ejercicio 1: operaciones aritméticas");

        //ingresar números
        Console.Write("Ingrese el primer número:");
        n1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Ingrese el segundo número:");
        n2 = Convert.ToDouble(Console.ReadLine());

        //operaciones
        suma = n1 + n2;
        res = n1 - n2;
        mul = n1 * n2;
        d = n1 / n2;
        div = n1 / n2;
        mod = n1 % n2;

        //resultados
        Console.WriteLine(n1 + " más " + n2 + " igual a " + suma);
        Console.WriteLine(n1 + " menos " + n2 + " igual a " + res);
        Console.WriteLine(n1 + " por " + n2 + " igual a " + mul);
        Console.WriteLine(n1 + " dividido " + n2 + " igual a " + d);
        Console.WriteLine(n1 + " / " + n2 + " igual a " + div);
        Console.WriteLine(n1 + " % " + n2 + " igual a " + mod);

        //segundo ejercicio

        Console.WriteLine("");
        Console.WriteLine("Ejercicio 2: operaciones booleanas");

        if (n1 > n2)
        {
            Console.WriteLine(n1 + " es mayor que " + n2);

        }
        else if (n1 < n2)
        {
            Console.WriteLine(n1 + " es menor que " + n2);

        }
        else if (n1 == n2)
        {
            Console.WriteLine(n1 + " es igual que " + n2);
        }
    }
}
