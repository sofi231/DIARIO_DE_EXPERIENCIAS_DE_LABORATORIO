﻿using System.Net.NetworkInformation;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Hola Mundo, soy Sofi");
        Console.ReadKey();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy Sofi");

        Console.Write("Hola Mundo");
        Console.Write(" soy Sofi\n");

        Console.WriteLine("\nIngrese su nombre: ");
        string nombre = Console.ReadLine();

        Console.Write("Hola Mundo ");
        Console.Write("soy " + nombre);
        Console.ReadKey();
    }
}
