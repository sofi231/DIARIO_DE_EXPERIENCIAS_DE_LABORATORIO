﻿namespace L8forms_ASAT_1078123
{
    partial class Sumatoria
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            groupBox1 = new GroupBox();
            cmbseleccion = new ComboBox();
            btnSeleccion = new Button();
            tabDatos = new TabControl();
            tabPage1 = new TabPage();
            lblResultatototal = new Label();
            txtnumero1 = new TextBox();
            lblResultado = new Label();
            lblIngrese = new Label();
            tabPage2 = new TabPage();
            lblResultadototal2 = new Label();
            txtnumero2 = new TextBox();
            lblResultado2 = new Label();
            label4 = new Label();
            tabPage3 = new TabPage();
            lblResultadototal3 = new Label();
            txtNumero3 = new TextBox();
            lblResultado3 = new Label();
            lblIngresar3 = new Label();
            groupBox1.SuspendLayout();
            tabDatos.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe Script", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(246, 17);
            label1.Name = "label1";
            label1.Size = new Size(203, 32);
            label1.TabIndex = 0;
            label1.Text = "LABORATORIO 8";
            label1.Click += label1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(cmbseleccion);
            groupBox1.Controls.Add(btnSeleccion);
            groupBox1.Location = new Point(22, 75);
            groupBox1.Margin = new Padding(3, 2, 3, 2);
            groupBox1.Name = "groupBox1";
            groupBox1.Padding = new Padding(3, 2, 3, 2);
            groupBox1.Size = new Size(251, 112);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Selección";
            // 
            // cmbseleccion
            // 
            cmbseleccion.FormattingEnabled = true;
            cmbseleccion.Items.AddRange(new object[] { "SUMATORIA", "TABLAS", "NÚMERO PERFECTO" });
            cmbseleccion.Location = new Point(14, 37);
            cmbseleccion.Margin = new Padding(3, 2, 3, 2);
            cmbseleccion.Name = "cmbseleccion";
            cmbseleccion.Size = new Size(224, 23);
            cmbseleccion.TabIndex = 0;
            cmbseleccion.SelectedIndexChanged += cmbseleccion_SelectedIndexChanged;
            // 
            // btnSeleccion
            // 
            btnSeleccion.Location = new Point(80, 75);
            btnSeleccion.Margin = new Padding(3, 2, 3, 2);
            btnSeleccion.Name = "btnSeleccion";
            btnSeleccion.Size = new Size(82, 22);
            btnSeleccion.TabIndex = 2;
            btnSeleccion.Text = "Seleccionar";
            btnSeleccion.UseVisualStyleBackColor = true;
            btnSeleccion.Click += btnSeleccion_Click;
            // 
            // tabDatos
            // 
            tabDatos.Controls.Add(tabPage1);
            tabDatos.Controls.Add(tabPage2);
            tabDatos.Controls.Add(tabPage3);
            tabDatos.Location = new Point(296, 65);
            tabDatos.Margin = new Padding(3, 2, 3, 2);
            tabDatos.Name = "tabDatos";
            tabDatos.SelectedIndex = 0;
            tabDatos.Size = new Size(466, 382);
            tabDatos.TabIndex = 3;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(lblResultatototal);
            tabPage1.Controls.Add(txtnumero1);
            tabPage1.Controls.Add(lblResultado);
            tabPage1.Controls.Add(lblIngrese);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Margin = new Padding(3, 2, 3, 2);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3, 2, 3, 2);
            tabPage1.Size = new Size(458, 354);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Sumatoria";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // lblResultatototal
            // 
            lblResultatototal.AutoSize = true;
            lblResultatototal.Location = new Point(175, 136);
            lblResultatototal.Name = "lblResultatototal";
            lblResultatototal.Size = new Size(0, 15);
            lblResultatototal.TabIndex = 3;
            // 
            // txtnumero1
            // 
            txtnumero1.Location = new Point(175, 62);
            txtnumero1.Margin = new Padding(3, 2, 3, 2);
            txtnumero1.Name = "txtnumero1";
            txtnumero1.Size = new Size(172, 23);
            txtnumero1.TabIndex = 2;
            txtnumero1.TextChanged += txtnumero_TextChanged;
            // 
            // lblResultado
            // 
            lblResultado.AutoSize = true;
            lblResultado.Font = new Font("Segoe Script", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblResultado.Location = new Point(27, 131);
            lblResultado.Name = "lblResultado";
            lblResultado.Size = new Size(86, 22);
            lblResultado.TabIndex = 1;
            lblResultado.Text = "Resultado:";
            lblResultado.Click += lblResultado_Click;
            // 
            // lblIngrese
            // 
            lblIngrese.AutoSize = true;
            lblIngrese.Font = new Font("Segoe Script", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblIngrese.Location = new Point(27, 62);
            lblIngrese.Name = "lblIngrese";
            lblIngrese.Size = new Size(135, 22);
            lblIngrese.TabIndex = 0;
            lblIngrese.Text = "Ingresar número:";
            lblIngrese.Click += lblIngrese_Click;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(lblResultadototal2);
            tabPage2.Controls.Add(txtnumero2);
            tabPage2.Controls.Add(lblResultado2);
            tabPage2.Controls.Add(label4);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Margin = new Padding(3, 2, 3, 2);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3, 2, 3, 2);
            tabPage2.Size = new Size(458, 354);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Tablas";
            tabPage2.UseVisualStyleBackColor = true;
            tabPage2.Click += tabPage2_Click;
            // 
            // lblResultadototal2
            // 
            lblResultadototal2.AutoSize = true;
            lblResultadototal2.Location = new Point(172, 137);
            lblResultadototal2.Name = "lblResultadototal2";
            lblResultadototal2.Size = new Size(0, 15);
            lblResultadototal2.TabIndex = 7;
            // 
            // txtnumero2
            // 
            txtnumero2.Location = new Point(175, 75);
            txtnumero2.Margin = new Padding(3, 2, 3, 2);
            txtnumero2.Name = "txtnumero2";
            txtnumero2.Size = new Size(193, 23);
            txtnumero2.TabIndex = 6;
            txtnumero2.TextChanged += txtnumero2_TextChanged;
            // 
            // lblResultado2
            // 
            lblResultado2.AutoSize = true;
            lblResultado2.Font = new Font("Segoe Script", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            lblResultado2.Location = new Point(24, 132);
            lblResultado2.Name = "lblResultado2";
            lblResultado2.Size = new Size(86, 22);
            lblResultado2.TabIndex = 5;
            lblResultado2.Text = "Resultado:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe Script", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(27, 75);
            label4.Name = "label4";
            label4.Size = new Size(135, 22);
            label4.TabIndex = 4;
            label4.Text = "Ingresar número:";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(lblResultadototal3);
            tabPage3.Controls.Add(txtNumero3);
            tabPage3.Controls.Add(lblResultado3);
            tabPage3.Controls.Add(lblIngresar3);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Margin = new Padding(3, 2, 3, 2);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(458, 354);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Número Perfecto";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // lblResultadototal3
            // 
            lblResultadototal3.AutoSize = true;
            lblResultadototal3.Location = new Point(137, 130);
            lblResultadototal3.Name = "lblResultadototal3";
            lblResultadototal3.Size = new Size(0, 15);
            lblResultadototal3.TabIndex = 4;
            // 
            // txtNumero3
            // 
            txtNumero3.Location = new Point(153, 75);
            txtNumero3.Name = "txtNumero3";
            txtNumero3.Size = new Size(192, 23);
            txtNumero3.TabIndex = 2;
            txtNumero3.TextChanged += txtNumero3_TextChanged;
            // 
            // lblResultado3
            // 
            lblResultado3.AutoSize = true;
            lblResultado3.Font = new Font("Segoe Script", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblResultado3.Location = new Point(22, 128);
            lblResultado3.Name = "lblResultado3";
            lblResultado3.Size = new Size(82, 20);
            lblResultado3.TabIndex = 1;
            lblResultado3.Text = "Resultado:";
            // 
            // lblIngresar3
            // 
            lblIngresar3.AutoSize = true;
            lblIngresar3.Font = new Font("Segoe Script", 9.75F, FontStyle.Regular, GraphicsUnit.Point);
            lblIngresar3.Location = new Point(22, 75);
            lblIngresar3.Name = "lblIngresar3";
            lblIngresar3.Size = new Size(125, 20);
            lblIngresar3.TabIndex = 0;
            lblIngresar3.Text = "Ingresar número:\r\n";
            lblIngresar3.Click += label2_Click;
            // 
            // Sumatoria
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(788, 469);
            Controls.Add(tabDatos);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Sumatoria";
            Text = "LABORATORIO 8";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            tabDatos.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private GroupBox groupBox1;
        private ComboBox cmbseleccion;
        private Button btnSeleccion;
        private TabControl tabDatos;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label lblResultado;
        private Label lblIngrese;
        private TabPage tabPage3;
        private TextBox txtnumero1;
        private Label lblResultatototal;
        private Label lblResultadototal2;
        private TextBox txtnumero2;
        private Label lblResultado2;
        private Label label4;
        private Label lblIngresar3;
        private Label lblResultadototal3;
        private TextBox txtNumero3;
        private Label lblResultado3;
    }
}