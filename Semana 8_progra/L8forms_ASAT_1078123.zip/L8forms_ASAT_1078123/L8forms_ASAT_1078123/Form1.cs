namespace L8forms_ASAT_1078123
{
    public partial class Sumatoria : Form
    {
        public int op = 0;
        public Sumatoria()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblIngrese_Click(object sender, EventArgs e)
        {

        }

        private void lblResultado_Click(object sender, EventArgs e)
        {

        }

        private void cmbseleccion_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (cmbseleccion.SelectedIndex)
            {
                case 0:
                    tabDatos.SelectedTab = tabPage1;
                    op = 1;
                    break;
                case 1:
                    tabDatos.SelectedTab = tabPage2;
                    op = 2;
                    break;
                case 2:
                    tabDatos.SelectedTab = tabPage3;
                    op = 3;
                    break;
            }
        }

        private void txtnumero_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void btnSeleccion_Click(object sender, EventArgs e)
        {
            try
            {
                switch (op)
                {
                    case 1:
                        int n = Convert.ToInt32(txtnumero1.Text);
                        int inicio = 1;
                        int sum = 0;

                        if (n > 0)
                        {
                            do
                            {

                                sum = sum + inicio;
                                inicio++;

                            } while (inicio <= n);
                        }
                        else
                        {
                            MessageBox.Show("Ingrese un n�mero mayor a 0");
                        }
                        lblResultatototal.Text = "La suma es: " + sum;
                        break;

                    case 2:
                        int x = Convert.ToInt32(txtnumero2.Text);
                        string multi = "\n";

                        if (x > 0)
                        {
                            for (int i = 1; i <= 10; i++)
                            {
                                multi = multi + Convert.ToString((i * x) + "\n");

                                lblResultadototal2.Text = multi;

                            }
                        }
                        else
                        {
                            MessageBox.Show("No es un n�mero");
                        }
                        break;

                    case 3:

                        int s = 0;
                        int n2 = Convert.ToInt32(txtNumero3.Text);

                        if (n2 > 0)
                        {
                            for (int y = 1; y < n2; y++)
                            {
                                if (n2 % y == 0)
                                {
                                    s = s + y;
                                }
                            }
                            if (s == n2)
                            {
                                lblResultadototal3.Text = "Es un n�mero perfecto";
                            }
                            else
                            {
                                lblResultadototal3.Text = "No es un n�mero perfecto";
                            }
                        }



                        break;
                }

            }
            catch
            {
                MessageBox.Show("Ingrese un n�mero v�lido");
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtnumero2_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtNumero3_TextChanged(object sender, EventArgs e)
        {

        }


    }
}
